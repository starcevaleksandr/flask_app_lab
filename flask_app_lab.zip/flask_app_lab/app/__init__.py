from flask import Flask
from flask import render_template

app = Flask(__name__)


from app.aam2207.st19 import bp as bp0719



bps = [
    ["[2207-19] Старцев 2207", bp0719]
]

for i, (title, bp) in enumerate(sorted(bps), start=1):
    app.register_blueprint(bp, url_prefix=f"/st{i}")


@app.route("/")
def index():
    return render_template("index.tpl", bps=sorted(bps))

if __name__ == "__main__":
	app.run(debug=True)
