from flask import Blueprint
from flask import g, request

#import app

bp = Blueprint('0719', __name__) # создание экземпляра класса Blueprint 
# (для создания "подприложений", подключаемых потом к общему)

if __name__ == '__init__':
    from employee_cont import Employee_Cont
else:
    from .employee_cont import Employee_Cont

def GetEmpl():
    if 'employees' not in g:
        g.employees = Employee_Cont()  # экземлпяр контейнерного класса
    return g.employees

@bp.route("/")  
def clientsindex():  
    return GetEmpl().ShowEmpl() # вывод всех сотрудников (основная страница)

@bp.route("/showform/<int:id>")
def showform(id):
    return GetEmpl().ShowForm(id) # вывод формы для добавления объекта

@bp.route("/delete/<int:id>")
def deleteitem(id):
    return GetEmpl().Delete(id) # обработка ссылки на удаление объекта

@bp.route("/add", methods=['POST'])
def add():
    return GetEmpl().Add() # обработка добавления объекта

@bp.teardown_request
def teardown_clients(ctx):
    GetEmpl().storage.Store() # выполняет функцию сохранения в БД при разрыве каждого запроса

if __name__ == "__main__":
    app.run(debug=True)
