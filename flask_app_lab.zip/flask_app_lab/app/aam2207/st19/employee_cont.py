from flask import render_template
from flask import request
from .database_storage import *
from .engineer import Engineer
from .employee import Employee
from .console_io import *
from .flask_io import *

class Employee_Cont:
    def __init__(self):
        self.storage = DBStorage() # экземпляр класса базы данных
        self.io = FlaskInputOutput(request) # экземпляр класса ввода/вывода на форму
        
    def ShowForm(self, id):
        return self.storage.GetItem(id).Output(self.io)
        
    def ShowEmpl(self):
        return render_template('aam2207/st19//employees.tpl', items=self.storage.GetItems(), selfurl='/'+request.url_rule.rule.split('/')[1])
        
    def Add(self):
        class_type = Engineer if request.form.get('Engineer') else Employee
        item = self.storage.GetItem(int(self.io.Input('id')))
        item.__class__ = class_type
        if __class__ == Engineer:
            item.class_type = 1  
        else:
            item.class_type = 0
        item.Input(self.io)
        self.storage.Add(item)
        return self.ShowEmpl()
            
    def Delete(self, id):
        self.storage.Delete(id)
        return self.ShowEmpl()




