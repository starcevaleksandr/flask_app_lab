class ConsoleInputOutput:
    def Input(self, field):
        return input(field)

    def Output(self, item):
        print(item)



