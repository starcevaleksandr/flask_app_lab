from flask import render_template, request

class FlaskInputOutput:
    def __init__(self, request):
        self.form = request.form

    def Input(self, field):
        return self.form.get(field)

    def Output(self, item):
        return render_template('aam2207//st19//form.tpl', item=item, selfurl='/'+request.url_rule.rule.split('/')[1])