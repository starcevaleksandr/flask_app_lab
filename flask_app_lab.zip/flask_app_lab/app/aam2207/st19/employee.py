from dataclasses import dataclass
from flask import render_template

@dataclass
class Employee:
    id: int = 0
    name: str = ''
    surname: str = ''
    age: int = 0
    #exp: int = 0
    salary: int=35000
  

    def __init__(self):
        self.class_type = 0

    def Show(self):
        return "Изменение сотрудников"

    def Input(self, io):
        self.id = int(io.Input('id'))
        self.name = io.Input('name')
        self.surname = io.Input('surname')
        self.age = int(io.Input('age'))
       # self.exp = int(io.Input('exp'))
        self.salary = int(io.Input('salary'))

    def Output(self, io):
        return io.Output(self)

    def DBLoad(self, r):
        self.id = r['id']
        self.name = r['name']
        self.surname = r['surname']
        self.age = r['age']
        #self.exp = r['exp']
        self.salary = r['salary']
  

    def DBStore(self, db):
        if not self.id or int(self.id) == 0:
            db.execute("insert into empl values(NULL, ?, ?, ?, ?, NULL, NULL, 0)",
                       (self.name, self.surname, self.age, self.salary ))
        else:
            db.execute("update empl set name=?, surname=?, age=?,  salary=?, category=NULL, gr=NULL, class_type=0 where id=?",
                       (self.name, self.surname, self.age, self.salary, self.id))
