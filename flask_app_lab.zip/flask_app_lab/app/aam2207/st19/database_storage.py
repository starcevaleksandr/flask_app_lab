import os, sqlite3
from .employee import Employee
from .engineer import Engineer


class DBStorage:
    def __init__(self):
        self.path = 'data/aam2207/st19/'
        self.Load()

    def Load(self):   # объявление таблицы
        if not os.path.exists(self.path):
            os.mkdir(self.path)
        self.db = sqlite3.connect(self.path + 'employees.sqlite', detect_types=sqlite3.PARSE_DECLTYPES)
        # объявление столбцов типов данных в них
        self.db.execute("""
           create table if not exists empl( 
               id integer primary key autoincrement,
               name text,
               surname text,
               age integer,
               salary integer,
               category integer,
               gr text,
               class_type integer
        )""")
        self.db.row_factory = sqlite3.Row
        self.dbc = self.db.cursor()

    def Store(self):  # функция сохранения в БД
        self.db.commit()
        self.db.close()

    def GetItem(self, id): # функция запроза записи из БД
        item = Engineer()
        if id > 0:
            self.dbc.execute("select * from empl where id=?", (id,))
            item.DBLoad(self.dbc.fetchone())
        return item

    def Add(self, item): # добавление объекта в БД
        item.DBStore(self.db)

    def Delete(self, id): # удаление записи из БД
        self.db.execute("delete from empl where id=?", (id,))

    def GetItems(self): # запрос всей таблицы из БД
        self.dbc.execute("select * from empl order by id desc")
        for r in self.dbc:
            if r[7] == 0:
                item = Employee()
            else:
                item = Engineer()
            item.DBLoad(r)
            yield (item) # возвращает генератор
