from .employee import Employee
from dataclasses import dataclass

@dataclass
class Engineer(Employee):
    category: int = 3
    gr: str = ''

    def __init__(self):
        super().__init__()
        self.class_type = 1

    def Input(self, io):
        Employee.Input(self, io)
        self.category = int(io.Input('category'))
        self.gr = str(io.Input('gr'))

    def DBLoad(self, r):
        Employee.DBLoad(self, r)
        self.category = r['category']
        self.gr = r['gr']

    def DBStore(self, db):
        if not self.id or int(self.id) == 0:
            db.execute("insert into empl values(NULL, ?, ?, ?, ?, ?, ?, 1)",
                       (self.name, self.surname, self.age, self.salary, self.category, self.gr))
        else:
            db.execute("update empl set name=?, surname=?, age=?, salary=?, category=?, gr=?, class_type =1 where id=?",
                       (self.name, self.surname, self.age, self.salary, self.category, self.gr, self.id))


